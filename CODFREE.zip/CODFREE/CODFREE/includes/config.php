<?php
// includes/config.php

$host = 'localhost';
$db   = 'codfree';
$user = 'root';
$pass = ''; // Use your DB password (XAMPP default is empty)
$charset = 'utf8mb4';

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
