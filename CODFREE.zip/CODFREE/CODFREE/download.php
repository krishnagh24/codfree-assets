<?php
require 'includes/config.php';
require 'includes/auth.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$project_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// 1. Get project details
$stmt = $conn->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

if (!$project) {
    die("Project not found.");
}

// 2. If project is free → allow download
if ($project['is_free']) {
    header("Location: " . $project['file_url']);
    exit();
}

// 3. Else check if user purchased this premium project
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? AND project_id = ? AND payment_status = 'paid'");
$stmt->bind_param("ii", $user_id, $project_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if ($order) {
    header("Location: " . $project['file_url']);
    exit();
} else {
    echo "❌ You have not purchased this premium project.";
}
