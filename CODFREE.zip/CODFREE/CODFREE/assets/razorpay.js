function initiatePayment(projectId, title, price, callback) {
    const options = {
        key: "RAZORPAY_KEY_HERE", // ✅ Replace with your Razorpay key
        amount: price * 100,
        currency: "INR",
        name: "CODFREE",
        description: `Purchase: ${title}`,
        image: "/assets/logo.png", // optional
        handler: function (response) {
            fetch("/payment_success.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    razorpay_payment_id: response.razorpay_payment_id,
                    project_id: projectId,
                    amount: price
                })
            })
            .then(res => res.text())
            .then(data => {
                alert("✅ Payment successful!");
                if (callback) callback();
            });
        },
        prefill: {
            email: window.email || ""
        },
        theme: {
            color: "#00f2ff"
        }
    };

    const rzp = new Razorpay(options);
    rzp.open();
}

document.getElementById("pay-btn").onclick = function () {
    initiatePayment(projectId, title, price, () => {
        window.location.href = redirectUrl;
    });
};
