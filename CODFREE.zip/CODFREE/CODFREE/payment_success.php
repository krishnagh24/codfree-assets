<?php
require 'includes/config.php';
require 'includes/auth.php';
requireLogin();

// Read JSON data from Razorpay
$data = json_decode(file_get_contents("php://input"), true);

$razorpay_id = $data['razorpay_payment_id'] ?? '';
$project_id = (int) $data['project_id'] ?? 0;
$user_id = $_SESSION['user_id'] ?? 0;
$amount = (int) $data['amount'] ?? 0;

if (!$razorpay_id || !$project_id || !$user_id) {
    http_response_code(400);
    echo "Invalid data.";
    exit;
}

// Mark project as purchased
$stmt = $conn->prepare("INSERT INTO purchases (user_id, project_id, razorpay_id, amount, purchased_at) VALUES (?, ?, ?, ?, NOW())");
$stmt->bind_param("iisi", $user_id, $project_id, $razorpay_id, $amount);
$stmt->execute();

// OPTIONAL: If user is purchasing a "premium plan" project, grant premium
$stmt2 = $conn->prepare("SELECT is_premium_plan FROM projects WHERE id = ?");
$stmt2->bind_param("i", $project_id);
$stmt2->execute();
$is_premium = $stmt2->get_result()->fetch_assoc()['is_premium_plan'] ?? 0;

if ($is_premium) {
    $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));
    $conn->query("UPDATE users SET premium = 1, premium_expires_at = '$expiry' WHERE id = $user_id");
}

echo "Payment logged successfully.";
?>
