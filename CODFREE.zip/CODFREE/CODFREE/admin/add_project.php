<?php
require '../includes/config.php';
require '../includes/auth.php';
requireAdmin(); // Only admin allowed

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $price = (float) $_POST['price'];
    $file_url = $_POST['file_url']; // or implement file upload
    $image_url = $_POST['image_url'];
    $is_free = isset($_POST['is_free']) ? 1 : 0;

    $stmt = $conn->prepare("INSERT INTO projects (title, price, file_url, image_url, is_free) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sdssi", $title, $price, $file_url, $image_url, $is_free);
    $stmt->execute();

    $msg = "✅ Project added successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Project | Admin</title>
</head>
<body>
  <h2>📁 Add New Project</h2>
  <?= $msg ? "<p>$msg</p>" : '' ?>
  <form method="POST">
    <input type="text" name="title" placeholder="Project Title" required><br><br>
    <input type="url" name="image_url" placeholder="Image URL" required><br><br>
    <input type="url" name="file_url" placeholder="Download File URL" required><br><br>
    <input type="number" name="price" placeholder="Price (₹)" step="0.01"><br><br>
    <label><input type="checkbox" name="is_free"> Free Project</label><br><br>
    <button type="submit">Add Project</button>
  </form>
</body>
</html>
