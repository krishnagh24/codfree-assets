<?php
require '../includes/config.php';
require '../includes/auth.php';
requireAdmin();

// Fetch all users
$users = $conn->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Users | Admin</title>
  <style>
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 10px; border: 1px solid #ccc; }
    .admin { color: green; font-weight: bold; }
  </style>
</head>
<body>
  <h2>👤 All Registered Users</h2>

  <table>
    <tr>
      <th>#</th>
      <th>Name</th>
      <th>Email</th>
      <th>Role</th>
      <th>Registered</th>
    </tr>
    <?php $i = 1; while($row = $users->fetch_assoc()): ?>
    <tr>
      <td><?= $i++ ?></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['email']) ?></td>
      <td class="<?= $row['role'] === 'admin' ? 'admin' : '' ?>"><?= $row['role'] ?></td>
      <td><?= $row['created_at'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
