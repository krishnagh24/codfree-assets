<?php
require '../includes/config.php';
require '../includes/auth.php';
requireAdmin(); // Only admin allowed

// Users count
$users = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];

// Orders count & income
$orderData = $conn->query("SELECT COUNT(*) AS total, SUM(amount) AS income FROM orders WHERE payment_status='paid'")->fetch_assoc();
$orders = $orderData['total'];
$income = $orderData['income'] ?? 0;

// Projects
$projects = $conn->query("SELECT COUNT(*) AS total FROM projects")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard | CODFREE</title>
  <style>
    .card { border: 1px solid #ccc; padding: 20px; margin: 10px; display: inline-block; }
  </style>
</head>
<body>
  <h1>📊 Admin Dashboard</h1>
  <div class="card">👥 Users: <?= $users ?></div>
  <div class="card">📦 Orders: <?= $orders ?></div>
  <div class="card">💰 Income: ₹<?= $income ?></div>
  <div class="card">📁 Projects: <?= $projects ?></div>
</body>
</html>
