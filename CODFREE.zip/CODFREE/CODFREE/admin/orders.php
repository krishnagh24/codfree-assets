<?php
require '../includes/config.php';
require '../includes/auth.php';
requireAdmin();

// Get orders with user & project info
$sql = "SELECT o.id, o.amount, o.payment_id, o.created_at, 
               u.name AS user_name, u.email, 
               p.title AS project_title
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN projects p ON o.project_id = p.id
        WHERE o.payment_status = 'paid'
        ORDER BY o.created_at DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>All Orders | Admin</title>
  <style>
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 10px; border: 1px solid #ccc; }
  </style>
</head>
<body>
  <h2>📦 All Paid Orders</h2>

  <table>
    <tr>
      <th>#</th>
      <th>User</th>
      <th>Email</th>
      <th>Project</th>
      <th>Amount</th>
      <th>Payment ID</th>
      <th>Date</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['user_name']) ?></td>
      <td><?= htmlspecialchars($row['email']) ?></td>
      <td><?= htmlspecialchars($row['project_title']) ?></td>
      <td>₹<?= $row['amount'] ?></td>
      <td><?= $row['payment_id'] ?></td>
      <td><?= $row['created_at'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
