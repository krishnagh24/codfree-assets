<?php
require '../includes/config.php';
require '../includes/auth.php';
requireAdmin();

$id = $_GET['id'] ?? 0;
$project = $conn->query("SELECT * FROM projects WHERE id = $id")->fetch_assoc();

if (!$project) {
  echo "Project not found."; exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $price = (float) $_POST['price'];
    $file_url = $_POST['file_url'];
    $image_url = $_POST['image_url'];
    $is_free = isset($_POST['is_free']) ? 1 : 0;

    $stmt = $conn->prepare("UPDATE projects SET title=?, price=?, file_url=?, image_url=?, is_free=? WHERE id=?");
    $stmt->bind_param("sdssii", $title, $price, $file_url, $image_url, $is_free, $id);
    $stmt->execute();

    $success = true;
    $project = $conn->query("SELECT * FROM projects WHERE id = $id")->fetch_assoc(); // Refresh data
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Project</title>
</head>
<body>
  <h2>✏️ Edit Project</h2>
  <?php if (isset($success)) echo "<p>✅ Updated successfully!</p>"; ?>
  <form method="POST">
    <input type="text" name="title" value="<?= htmlspecialchars($project['title']) ?>" required><br><br>
    <input type="url" name="image_url" value="<?= htmlspecialchars($project['image_url']) ?>" required><br><br>
    <input type="url" name="file_url" value="<?= htmlspecialchars($project['file_url']) ?>" required><br><br>
    <input type="number" name="price" value="<?= $project['price'] ?>" step="0.01"><br><br>
    <label><input type="checkbox" name="is_free" <?= $project['is_free'] ? 'checked' : '' ?>> Free</label><br><br>
    <button type="submit">💾 Update Project</button>
  </form>

  <form method="POST" action="delete_project.php" onsubmit="return confirm('Delete this project?')">
    <input type="hidden" name="id" value="<?= $id ?>">
    <button type="submit" style="color: red;">🗑️ Delete Project</button>
  </form>
</body>
</html>
