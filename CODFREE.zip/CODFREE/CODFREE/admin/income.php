SELECT SUM(amount) as total_income, COUNT(*) as total_sales FROM purchases;
