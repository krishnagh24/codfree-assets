<?php
require '../includes/config.php';
require '../includes/auth.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST['id'];
  $conn->query("DELETE FROM projects WHERE id = $id");
  header("Location: dashboard.php");
  exit();
}
