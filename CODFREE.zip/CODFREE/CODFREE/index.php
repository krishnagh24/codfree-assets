<?php
require 'includes/config.php';
require 'includes/auth.php';

$sql = "SELECT * FROM projects ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
  <title>CODFREE | Mini Project Store</title>
  <link rel="stylesheet" href="assets/style.css"> <!-- optional -->
</head>
<body>
  <h1>🔥 All Projects</h1>
  <div class="projects-grid">
    <?php while ($project = $result->fetch_assoc()): ?>
      <div class="project-card">
        <img src="<?= $project['image_url'] ?>" alt="Project" />
        <h2><?= $project['title'] ?></h2>
        <p><?= substr($project['description'], 0, 100) ?>...</p>
        <p><strong>₹<?= $project['price'] ?></strong></p>

        <?php if ($project['is_free']): ?>
          <a href="download.php?id=<?= $project['id'] ?>">Free Download</a>
        <?php else: ?>
          <a href="checkout.php?id=<?= $project['id'] ?>">Buy Now</a>
        <?php endif; ?>
      </div>
    <?php endwhile; ?>
  </div>
</body>
</html>
