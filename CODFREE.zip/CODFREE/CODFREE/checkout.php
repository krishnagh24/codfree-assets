<?php
require 'includes/config.php';
require 'includes/auth.php';
requireLogin();

$project_id = $_GET['id'] ?? 0;

// Fetch project info
$stmt = $conn->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();

if (!$project || $project['is_free']) {
    die("Invalid premium project.");
}

$title = htmlspecialchars($project['title']);
$price = (int)$project['price'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buy <?= $title ?> | CODFREE</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #111;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .box {
            background: #1e1e1e;
            padding: 2rem;
            border-radius: 14px;
            box-shadow: 0 0 20px #00ffff44;
            max-width: 400px;
            text-align: center;
        }

        button {
            padding: 10px 20px;
            font-size: 18px;
            background: #00f2ff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #00c2ff;
        }
    </style>
</head>
<body>

<div class="box">
    <h1>Buy: <?= $title ?></h1>
    <p>Price: ₹<?= $price ?></p>
    <button id="pay-btn">Pay Now</button>
</div>

<script>
    const projectId = <?= $project['id'] ?>;
    const title = "<?= $title ?>";
    const price = <?= $price ?>;
    const redirectUrl = "download.php?id=" + projectId;
    const email = "<?= $_SESSION['email'] ?? '' ?>"; // Optional
</script>

<!-- ✅ External Razorpay payment logic -->
<script src="/assets/razorpay.js"></script>

</body>
</html>
